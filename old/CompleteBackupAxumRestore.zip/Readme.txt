For uploading you must start the upload.bat under administrator rights.

