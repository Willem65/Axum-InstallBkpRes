For uploading you must start the upload.bat under administrator rights.

Also you must have installed Putty on your pc.

