Place delete-enginelog.sh in the /root directory

Place the content in rc.local in the /etc/rc.local

Make sure the files are executable ( chmod 777 )

There wil be a log file genarated in the /var/log named ( axumdeleteLog.log